/**
 * @name MentionFix
 * @author Kaan
 * @version 2.0.6
 * @description Hate the `@unknown-user` when mentioning someone you've never met? Yeah this fixes that. :>
 * @source https://github.com/zrodevkaan/BDPlugins/tree/main/Plugins/MentionFix/MentionFix.plugin.js
 * @invite t3zMgv7Nvb
 * @stable 634304
 * @canary 635660
 */
"use strict";

// helpers/webpack.ts
var { Webpack } = BdApi;

// helpers/index.tsx
var { Webpack: Webpack2, React, ContextMenu, Hooks } = BdApi;
var { createElement, forwardRef } = React;
function styledBase(tag, cssOrFn) {
  const Styled = (props) => {
    const style = typeof cssOrFn === "function" ? cssOrFn(props) : cssOrFn;
    return createElement(tag, { ...props, style: { ...style, ...props.style } });
  };
  Styled.displayName = `styled.${String(tag)}`;
  return Styled;
}
var styled = new Proxy(styledBase, {
  get: (target, p) => (css) => target(p, css)
});
function getKey(module2, fn) {
  for (const key in module2) {
    if (fn(module2[key])) return { key, module: module2 };
  }
}
function lazyExport(getter) {
  let cached;
  const resolve = () => cached ??= getter();
  return new Proxy({}, {
    get: (_, key) => resolve()?.[key],
    set: (_, key, value) => {
      const target = resolve();
      if (target) target[key] = value;
      return true;
    },
    has: (_, key) => {
      const t = resolve();
      return t ? key in t : false;
    },
    ownKeys: () => {
      const t = resolve();
      return t ? Reflect.ownKeys(t) : [];
    },
    getOwnPropertyDescriptor: (_, key) => {
      const t = resolve();
      const desc = t ? Reflect.getOwnPropertyDescriptor(t, key) : void 0;
      return desc && { ...desc, configurable: true };
    }
  });
}
function lazyStore(name) {
  return lazyExport(() => Webpack2.getStore(name));
}
var Stores = {
  User: lazyStore("UserStore"),
  Guild: lazyStore("GuildStore"),
  Channel: lazyStore("ChannelStore"),
  GuildMember: lazyStore("GuildMemberStore"),
  SelectedGuild: lazyStore("SelectedGuildStore"),
  SelectedChannel: lazyStore("SelectedChannelStore"),
  Message: lazyStore("MessageStore")
};

// src/MentionFix/index.tsx
var { Webpack: Webpack3, Patcher, React: React2, Hooks: Hooks2, Components } = new BdApi("MentionFix");
var FetchUser = getKey(Webpack3.getModule(Webpack3.Filters.combine(Webpack3.Filters.bySource("UserProfileModalActionCreators"), Webpack3.Filters.bySource("CURRENT_USER_UPDATE"))), (x) => String(x).includes("USER_UPDATE") && !String(x).includes("USER_PROFILE_FETCH_START") && String(x).includes("Promise.resolve"));
var UserMention = getKey(Webpack3.getBySource(".A.USER_MENTION),"), (x) => String(x).includes("USER_MENTION"));
var UserComponent = UserMention.module[UserMention.key];
function queuer(worker, { concurrency = 3 } = {}) {
  const pending = /* @__PURE__ */ new Map();
  const queue = [];
  let active = 0;
  function runNext() {
    if (active >= concurrency || queue.length === 0) return;
    const { key, resolve, reject } = queue.shift();
    active++;
    worker(key).then(resolve, reject).finally(() => {
      active--;
      pending.delete(key);
      runNext();
    });
  }
  return function enqueue(key) {
    if (pending.has(key)) return pending.get(key);
    const promise = new Promise((resolve, reject) => {
      queue.push({ key, resolve, reject });
    });
    pending.set(key, promise);
    runNext();
    return promise;
  };
}
var fetchUserQueue = queuer(
  (userId) => FetchUser.module[FetchUser.key](userId),
  { concurrency: 8 }
);
function CustomMention({ args }) {
  const userId = args.userId ?? args.parsedUserId;
  const data = Hooks2.useStateFromStores([Webpack3.Stores.UserStore, Webpack3.Stores.ChannelStore], () => ({
    user: Webpack3.Stores.UserStore.getUser(userId),
    channel: Webpack3.Stores.ChannelStore.getChannel(args.channelId)
  }));
  React2.useEffect(() => {
    if (data.user) return;
    fetchUserQueue(userId).then(() => Webpack3.Stores.UserStore.emitChange());
  }, [data.user]);
  return !data.user ? /* @__PURE__ */ BdApi.React.createElement(Components.Spinner, null) : /* @__PURE__ */ BdApi.React.createElement(UserComponent, { ...args });
}
var MentionFix = class {
  start() {
    Patcher.after(UserMention.module, UserMention.key, (that, [args], res) => {
      const userId = args.userId ?? args.parsedUserId;
      if (!userId || Webpack3.Stores.UserStore.getUser(userId)) return res;
      args.userId = args.parsedUserId;
      return /* @__PURE__ */ BdApi.React.createElement(CustomMention, { args });
    });
  }
  stop() {
    Patcher.unpatchAll();
  }
};
module.exports = MentionFix;
